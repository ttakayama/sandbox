INSTALATION:
1. Download and up-zip Skeuomorphism.it
2. Double click the extension to open Adobe Extension Manager.
3. Click OK, and acknowledge the warning message to start the installation.
4. Restart Photoshop if it's open
5. You should now be able to navigate to Window > Extensions > Skeuomorphism.it

HOW TO USE
Simply open one of your favourite site designs and click "Work the magic", if you don't like the outcome, simply hit undo! If nothing happened then your already a flat design pro!

UNINSTALL
Uninstall via Extension Manager, Hit Remove.