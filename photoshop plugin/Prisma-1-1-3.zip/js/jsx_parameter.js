JSXParameter = {

  encode: function(params) {
    return JSXParameter.hexEncode(JSON.stringify(params));
  },

  decode: function(encoded) {
    return JSON.parse(JSXParameter.hexDecode(encoded));
  },

  hexDecode: function(encoded) {
    var decoded = '';
    for (var i = 0; i < encoded.length; i += 3) {
      decoded += String.fromCharCode('0x' + encoded.substring(i, i + 3));
    }
    return decoded;
  },

  hexEncode: function(str) {
    var result = '';
    var hex;
    var i = 0;

    while (i < str.length) {
      hex = str.charCodeAt(i++).toString(16);
      while (hex.length < 3) hex = '0' + hex;
      result += hex;
    }
    return result;
  }
}
