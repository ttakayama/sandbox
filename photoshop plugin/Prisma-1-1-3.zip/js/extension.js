var fs = require('fs');
var path = require('path');
var csInterface = new CSInterface();
var prismaIframe = document.getElementById('prisma-iframe');

window.Extension = {
  //URL: 'http://192.168.1.31:3000', // development (change IP)
  URL: 'https://prisma-backend.herokuapp.com/', // production
  ID: 'com.codeadventure.prisma',
  EXTENSION_VERSION: '1.1.1',
  JSX_EXECUTE: 'executeFunctionWithEncodedParameter',

  // Tell the web app which application is running
  isRunningInPhotoshop: true,
  hostApplicationVersion: '15',

  // Map of all host adapter events that are currently listened to
  registeredHostEvents: {},

  // Setup communication channel betwenn web application and JSX layer
  execute: function (jsxActionName, data, callback) {

    var encodedArgs = JSXParameter.encode({
      scriptName: jsxActionName,
      parameter: data === null ? {} : JSON.parse(data)
    });

    script = Extension.JSX_EXECUTE + '("' + encodedArgs + '")';
    csInterface.evalScript(script, function(result) {
      result = result.replace('<object><property id="json"><string>', '');
      result = result.replace('</string></property></object>', '');

      if (result == EvalScript_ErrMessage) {
        callback({ success: false });
      }
      else {
        callback({ success: true, data: JSXParameter.decode(result) });
      }
    });
  },

  listenToHostAdapterEvents: function(events) {
    console.log(events);
    var i;
    events = events.split(',');
    for (i = 0; i < events.length; i++) {
      var eventName = events[i];
      if(!Extension.registeredHostEvents[eventName]) {
        Extension.registerHostEventHandler(eventName);
      }
    }
  },

  registerHostEventHandler: function(eventName) {
    console.log("REGISTER EVENT: ", eventName);
    var register = new CSEvent("com.adobe.PhotoshopRegisterEvent", "APPLICATION");
    var unregister = new CSEvent("com.adobe.PhotoshopUnRegisterEvent", "APPLICATION");
    register.extensionId = unregister.extensionId = Extension.ID;
    register.data = unregister.data = PSEvent[eventName];

    csInterface.dispatchEvent(unregister);
    csInterface.dispatchEvent(register);
    Extension.registeredHostEvents[eventName] = true;
  },

  handlePhotoshopEvent: function(hostEvent) {
    events = hostEvent.data.split(',');
    getEventName = 'typeIDToStringID(' + parseInt(events[0]) + ')';
    csInterface.evalScript(getEventName, function(eventName) {
      console.log("HANDLE PHOTOSHOP EVENT:", eventName);
      Extension.handleHostAdapterEvent(eventName.toUpperCase());
    });
  },

  // Is is overriden by the web app
  handleHostAdapterEvent: function() {},

  onIframeLoaded: function() {
    prismaIframe.classList.add("is-loaded");
  },

  openURLInDefaultBrowser: csInterface.openURLInDefaultBrowser,

  loseFocus: function() {
    var csEvent = new CSEvent("com.adobe.PhotoshopLoseFocus", "APPLICATION");
    csEvent.extensionId = Extension.ID;
    csInterface.dispatchEvent(csEvent);
  },

  readBinaryFile: function(filePath) {
    contents = fs.readFileSync(filePath).toString('binary');
    return btoa(unescape(encodeURIComponent(contents)));
  }
};

// Ensure there is only one photoshop callback listener
csInterface.removeEventListener('PhotoshopCallback', Extension.handlePhotoshopEvent);
csInterface.addEventListener('PhotoshopCallback', Extension.handlePhotoshopEvent);

// Load the iframe after the page was rendered because otherwise the
// splash screen doesn't show immediately
window.onload = function() {
  prismaIframe.onload = Extension.onIframeLoaded;
  prismaIframe.src = Extension.URL;
};
// Make the extension persistent when closing / reopening
var event = new CSEvent("com.adobe.PhotoshopPersistent", "APPLICATION");
event.extensionId = Extension.ID;
csInterface.dispatchEvent(event);
