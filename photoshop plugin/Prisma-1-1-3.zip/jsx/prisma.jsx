﻿if (typeof JSON !== 'object') {  JSON = {};}(function () {  'use strict';  function f(n) {    // Format integers to have at least two digits.    return n < 10 ? '0' + n : n;  }  if (typeof Date.prototype.toJSON !== 'function') {    Date.prototype.toJSON = function () {      return isFinite(this.valueOf())        ? this.getUTCFullYear()     + '-' +        f(this.getUTCMonth() + 1) + '-' +        f(this.getUTCDate())      + 'T' +        f(this.getUTCHours())     + ':' +        f(this.getUTCMinutes())   + ':' +        f(this.getUTCSeconds())   + 'Z'        : null;    };    String.prototype.toJSON      =      Number.prototype.toJSON  =        Boolean.prototype.toJSON = function () {          return this.valueOf();        };  }  var cx,    escapable,    gap,    indent,    meta,    rep;  function quote(string) {// If the string contains no control characters, no quote characters, and no// backslash characters, then we can safely slap some quotes around it.// Otherwise we must also replace the offending characters with safe escape// sequences.    escapable.lastIndex = 0;    return escapable.test(string) ? '"' + string.replace(escapable, function (a) {      var c = meta[a];      return typeof c === 'string'        ? c        : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);    }) + '"' : '"' + string + '"';  }  function str(key, holder) {// Produce a string from holder[key].    var i,          // The loop counter.      k,          // The member key.      v,          // The member value.      length,      mind = gap,      partial,      value = holder[key];// If the value has a toJSON method, call it to obtain a replacement value.    if (value && typeof value === 'object' &&      typeof value.toJSON === 'function') {      value = value.toJSON(key);    }// If we were called with a replacer function, then call the replacer to// obtain a replacement value.    if (typeof rep === 'function') {      value = rep.call(holder, key, value);    }// What happens next depends on the value's type.    switch (typeof value) {      case 'string':        return quote(value);      case 'number':// JSON numbers must be finite. Encode non-finite numbers as null.        return isFinite(value) ? String(value) : 'null';      case 'boolean':      case 'null':// If the value is a boolean or null, convert it to a string. Note:// typeof null does not produce 'null'. The case is included here in// the remote chance that this gets fixed someday.        return String(value);// If the type is 'object', we might be dealing with an object or an array or// null.      case 'object':// Due to a specification blunder in ECMAScript, typeof null is 'object',// so watch out for that case.        if (!value) {          return 'null';        }// Make an array to hold the partial results of stringifying this object value.        gap += indent;        partial = [];// Is the value an array?        if (Object.prototype.toString.apply(value) === '[object Array]') {// The value is an array. Stringify every element. Use null as a placeholder// for non-JSON values.          length = value.length;          for (i = 0; i < length; i += 1) {            partial[i] = str(i, value) || 'null';          }// Join all of the elements together, separated with commas, and wrap them in// brackets.          v = partial.length === 0            ? '[]'            : gap            ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']'            : '[' + partial.join(',') + ']';          gap = mind;          return v;        }// If the replacer is an array, use it to select the members to be stringified.        if (rep && typeof rep === 'object') {          length = rep.length;          for (i = 0; i < length; i += 1) {            if (typeof rep[i] === 'string') {              k = rep[i];              v = str(k, value);              if (v) {                partial.push(quote(k) + (gap ? ': ' : ':') + v);              }            }          }        } else {// Otherwise, iterate through all of the keys in the object.          for (k in value) {            if (Object.prototype.hasOwnProperty.call(value, k)) {              v = str(k, value);              if (v) {                partial.push(quote(k) + (gap ? ': ' : ':') + v);              }            }          }        }// Join all of the member texts together, separated with commas,// and wrap them in braces.        v = partial.length === 0          ? '{}'          : gap          ? '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}'          : '{' + partial.join(',') + '}';        gap = mind;        return v;    }  }// If the JSON object does not yet have a stringify method, give it one.  if (typeof JSON.stringify !== 'function') {    escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;    meta = {    // table of character substitutions      '\b': '\\b',      '\t': '\\t',      '\n': '\\n',      '\f': '\\f',      '\r': '\\r',      '"' : '\\"',      '\\': '\\\\'    };    JSON.stringify = function (value, replacer, space) {// The stringify method takes a value and an optional replacer, and an optional// space parameter, and returns a JSON text. The replacer can be a function// that can replace values, or an array of strings that will select the keys.// A default replacer method can be provided. Use of the space parameter can// produce text that is more easily readable.      var i;      gap = '';      indent = '';// If the space parameter is a number, make an indent string containing that// many spaces.      if (typeof space === 'number') {        for (i = 0; i < space; i += 1) {          indent += ' ';        }// If the space parameter is a string, it will be used as the indent string.      } else if (typeof space === 'string') {        indent = space;      }// If there is a replacer, it must be a function or an array.// Otherwise, throw an error.      rep = replacer;      if (replacer && typeof replacer !== 'function' &&        (typeof replacer !== 'object' ||          typeof replacer.length !== 'number')) {        throw new Error('JSON.stringify');      }// Make a fake root object containing our value under the key of ''.// Return the result of stringifying the value.      return str('', {'': value});    };  }// If the JSON object does not yet have a parse method, give it one.  if (typeof JSON.parse !== 'function') {    cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;    JSON.parse = function (text, reviver) {// The parse method takes a text and an optional reviver function, and returns// a JavaScript value if the text is a valid JSON text.      var j;      function walk(holder, key) {// The walk method is used to recursively walk the resulting structure so// that modifications can be made.        var k, v, value = holder[key];        if (value && typeof value === 'object') {          for (k in value) {            if (Object.prototype.hasOwnProperty.call(value, k)) {              v = walk(value, k);              if (v !== undefined) {                value[k] = v;              } else {                delete value[k];              }            }          }        }        return reviver.call(holder, key, value);      }// Parsing happens in four stages. In the first stage, we replace certain// Unicode characters with escape sequences. JavaScript handles many characters// incorrectly, either silently deleting them, or treating them as line endings.      text = String(text);      cx.lastIndex = 0;      if (cx.test(text)) {        text = text.replace(cx, function (a) {          return '\\u' +            ('0000' + a.charCodeAt(0).toString(16)).slice(-4);        });      }// In the second stage, we run the text against regular expressions that look// for non-JSON patterns. We are especially concerned with '()' and 'new'// because they can cause invocation, and '=' because it can cause mutation.// But just to be safe, we want to reject all unexpected forms.// We split the second stage into 4 regexp operations in order to work around// crippling inefficiencies in IE's and Safari's regexp engines. First we// replace the JSON backslash pairs with '@' (a non-JSON character). Second, we// replace all simple value tokens with ']' characters. Third, we delete all// open brackets that follow a colon or comma or that begin the text. Finally,// we look to see that the remaining characters are only whitespace or ']' or// ',' or ':' or '{' or '}'. If that is so, then the text is safe for eval.      if (/^[\],:{}\s]*$/        .test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')          .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')          .replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {// In the third stage we use the eval function to compile the text into a// JavaScript structure. The '{' operator is subject to a syntactic ambiguity// in JavaScript: it can begin a block or an object literal. We wrap the text// in parens to eliminate the ambiguity.        j = eval('(' + text + ')');// In the optional fourth stage, we recursively walk the new structure, passing// each name/value pair to a reviver function for possible transformation.        return typeof reviver === 'function'          ? walk({'': j}, '')          : j;      }// If the text is not JSON parseable, then a SyntaxError is thrown.      throw new SyntaxError('JSON.parse');    };  }}());
(function (globalNamespace) {
  "use strict";

  function applyMethodName(method, name) {
    method.toString = function () { return name; };
  }

  function applyConstructorName(NewClass, name) {
    NewClass.toString = function () { return name; };
  }

  function applyClassNameToPrototype(NewClass, name) {
    NewClass.prototype.toString = function () { return name; };
    NewClass.prototype.Class = NewClass;
  }

  /**
   * Creates and returns a new JavaScript 'class' as constructor function.
   *
   * @param {String} classPath Namespaces and class name separated by '.' (e.g: "my.awesome.TestClass")
   * @param {Object} classDefinition Properties and methods that are added to the prototype
   * @param {Boolean} keepLocal Indicates if the global namespace should be polluted (creating namespaces)
   *
   * @returns {Function} The new class constructor
   *
   * @memberof! <global>
   */
  function Class (classPath, classDefinition, keepLocal) {
    var SuperClass, implementations, className, Constructor, ClassConstructor;

    // class path is always needed
    if(typeof classPath !== 'string') {
      throw new Error('Please give your class a name. Pass "true" as last parameter to avoid global namespace pollution');
    }

    // class definition is optional
    if(!classDefinition) {
      classDefinition = {};
    }

    SuperClass = classDefinition.Extends || null;
    delete classDefinition.Extends;

    implementations = classDefinition.Implements || null;
    delete classDefinition.Implements;

    Constructor = classDefinition.Constructor || null;
    delete classDefinition.Constructor;

    if (!Constructor) {
      if (SuperClass) {
        // invoke constructor of superclass by default
        Constructor = function () { SuperClass.apply(this, arguments); };
      } else {
        // there is no super class, default constructor is no-op method
        Constructor = function () {};
      }
    }

    className = classPath.substr(classPath.lastIndexOf('.') + 1);

    /*jslint evil: true */
    ClassConstructor = new Function('Constructor', 'return function ' + className + '() { Constructor.apply(this, arguments); }')(Constructor);

    applyConstructorName(ClassConstructor, classPath);

    Class.inherit(ClassConstructor, SuperClass);

    Class.implement(ClassConstructor, implementations);

    applyClassNameToPrototype(ClassConstructor, classPath);

    Class.extend(ClassConstructor, classDefinition, true);

    if(!keepLocal) {
      Class.namespace(classPath, ClassConstructor);
    }

    return ClassConstructor;
  };

  /**
   * Adds all properties of the extension object to the target object. 
   * Can be configured to override existing properties.
   *
   * @param  {Object} target
   * @param  {Object} extension
   * @param  {boolean} shouldOverride
   *
   * @static
   */
  Class.augment = function (target, extension, shouldOverride) {

    var propertyName, property, targetHasProperty,
      propertyWouldNotBeOverriden, extensionIsPlainObject, className;

    for (propertyName in extension) {

      if (extension.hasOwnProperty(propertyName)) {

        targetHasProperty = target.hasOwnProperty(propertyName);

        if (shouldOverride || !targetHasProperty) {

          property = target[propertyName] = extension[propertyName];

          if (typeof property === 'function') {
            extensionIsPlainObject = (extension.toString === Object.prototype.toString);
            className = extensionIsPlainObject ? target.constructor : extension.constructor;

            applyMethodName(property, className + "::" + propertyName);
          }
        }
      }
    }
  };

  /**
   * Extend the given class prototype with properties and methods
   *
   * @param {function()} TargetClass Constructor of existing class
   * @param {Object} extension Properties and methods that are added to the prototype
   * @param {boolean} shouldOverride Specify if the extension should
   * override existing properties on the target class prototype
   */
  Class.extend = function (TargetClass, extension, shouldOverride) {

    // add static properties of the super class to the class namespace
    if(TargetClass.Super && TargetClass.Super._STATIC_) {
      Class.augment(TargetClass, TargetClass.Super._STATIC_, true);
    }

    // add static properties of the target class definition
    // (possibly overriding static variables copied from the super class)
    if (extension.STATIC) {

      // add static properties and methods to the class namespace
      Class.augment(TargetClass, extension.STATIC, true);

      // save the static definitions into special var on the class namespace
      TargetClass._STATIC_ = extension.STATIC;
      delete extension.STATIC;
    }

    // add properties and methods to the class prototype
    Class.augment(TargetClass.prototype, extension, shouldOverride);
  };

  /**
   * Sets up the classical inheritance chain between
   * the base class and the sub class. Adds a static
   * property to the sub class that references the 
   * base class.
   * 
   * @param  {Function} SubClass
   * @param  {Function} SuperClass
   * @return {undefined}
   */
  Class.inherit = function (SubClass, SuperClass) {

    if (SuperClass) {

      var SuperClassProxy = function () {};
      SuperClassProxy.prototype = SuperClass.prototype;

      SubClass.prototype = new SuperClassProxy();
      SubClass.prototype.constructor = SubClass;


      SubClass.Super = SuperClass;

      Class.extend(SubClass, SuperClass, false);
    }
  };

  /**
   * Copies the prototype properties of the given
   * implementations to the class prototype.
   * 
   * @param  {Function} TargetClass
   * @param  {Function|Array} implementations
   * @return {undefined}
   */
  Class.implement = function (TargetClass, implementations) {

    if (implementations) {
      var index;

      if (typeof implementations === 'function') {
        implementations = [implementations];
      }

      for (index = 0; index < implementations.length; index++) {
        Class.augment(TargetClass.prototype, implementations[index].prototype, true);
      }
    }
  };

  /**
   * Creates a namespace chain and exposes the given object
   * at the last position of the given namespace.
   *
   * e.g: Class.namespace('lib.util.Math', {})
   * would create a namespace like window.lib.util.Math and 
   * assign the given object literal to last part: 'Math'
   * 
   * @param  {String} namespacePath
   * @param  {Object} exposedObject
   * @return {undefined}
   */
  Class.namespace = function (namespacePath, exposedObject) {

    if(typeof globalNamespace.define === "undefined") {
      var classPathArray, className, currentNamespace, currentPathItem, index;
    
      classPathArray = namespacePath.split('.');
      className = classPathArray[classPathArray.length - 1];
    
      currentNamespace = globalNamespace;
    
      for(index = 0; index < classPathArray.length - 1; index += 1) {
        currentPathItem = classPathArray[index];
        
        if(typeof currentNamespace[currentPathItem] === "undefined") {
          currentNamespace[currentPathItem] = {};
        }
        
        currentNamespace = currentNamespace[currentPathItem];
      }
      
      currentNamespace[className] = exposedObject;
    }
  };

  globalNamespace.Class = Class;

}(this));
!function(){"use strict";Class("Dependance.DependencyProvider",{_type:null,Constructor:function(a){this._type=a},getType:function(){return this._type}})}(),function(){"use strict";Class("Dependance.providers.ClassProvider",{Extends:Dependance.DependencyProvider,provide:function(){var a=this.getType();return new a}})}(),function(){"use strict";Class("Dependance.providers.SingletonProvider",{Extends:Dependance.DependencyProvider,_singletonInstance:null,provide:function(){if(null===this._singletonInstance){var a=this.getType();this._singletonInstance=new a}return this._singletonInstance}})}(),function(){"use strict";Class("Dependance.providers.ValueProvider",{Extends:Dependance.DependencyProvider,provide:function(){return this.getType()}})}(),function(){"use strict";Class("Dependance.InjectionMapping",{_requestType:null,_responseType:null,_dependencyProvider:null,_isStaticValue:!1,Constructor:function(a,b){this._requestType=a,b?this._dependencyProvider=b:this.toClass(a)},toClass:function(a){return this._responseType=a,this._dependencyProvider=new Dependance.providers.ClassProvider(a),this},toSingleton:function(a){return this._responseType=a,this._dependencyProvider=new Dependance.providers.SingletonProvider(a),this},asSingleton:function(){return this.toSingleton(this._requestType)},toValue:function(a){return this._responseType=a,this._dependencyProvider=new Dependance.providers.ValueProvider(a),this},toStaticValue:function(a){this.toValue(a),this._isStaticValue=!0},getProvider:function(){return this._dependencyProvider},getResponseType:function(){return this._responseType},getRequestType:function(){return this._requestType},getValue:function(){return this._dependencyProvider.provide()},isStaticValue:function(){return this._isStaticValue}})}(),function(){"use strict";Class("Dependance.MappingFactory",{_mappings:null,Constructor:function(){this._mappings={}},create:function(a){this.hasMappingFor(a)&&this._throwMappingWouldBeOverridenError(a);var b=new Dependance.InjectionMapping(a);return this._addMappingForIdentifier(a,b),b},add:function(a){var b=a.getRequestType();this.hasMappingFor(b)&&this._throwMappingWouldBeOverridenError(b),this._addMappingForIdentifier(b,a)},get:function(a){if(!this.hasMappingFor(a))throw new Error("No mapping for identifier "+a+" was found.");return this._mappings[this._stringify(a)]},hasMappingFor:function(a){return a=this._stringify(a),this._mappings[a]?!0:!1},_throwMappingWouldBeOverridenError:function(a){throw new Error("There already exists a mapping for "+a+", this would be overriden. You have to unmap the type before mapping it again.")},_stringify:function(a){return"string"!=typeof a&&(a=a.toString()),a},_addMappingForIdentifier:function(a,b){a=this._stringify(a),this._mappings[a]=b}})}(),function(){"use strict";Class("Dependance.Injector",{Constructor:function(a){this._mappingFactory=a?a:new Dependance.MappingFactory},_mappingFactory:null,map:function(a){return this._mappingFactory.create(a)},injectInto:function(a){this._injectInto(a,a.Class)},get:function(a){return this._getValueForIdentifier(a,null,!1)},hasMappingFor:function(a){return this._mappingFactory.hasMappingFor(a)},getMappingFor:function(a){var b=this._mappingFactory.get(a);return b},getMappingFactory:function(){return this._mappingFactory},isDependentOn:function(a,b){if("string"==typeof a)return!1;var c,d=a.prototype.Dependencies;if("object"!=typeof d||null===b)return!1;for(c in d)if(d.hasOwnProperty(c)&&d[c]===b)return!0;return!1},_getValueForIdentifier:function(a,b,c){var d,e,f=null;return d=this.getMappingFor(a),f=d.getValue(),c||d.isStaticValue()||(e=!!this.isDependentOn(a,b),this._injectInto(f,f.Class,a,b,e)),f},_injectInto:function(a,b,c,d,e){if(!a._hasDependenciesInjected){if(a&&b&&b.Super&&this._injectInto(a,b.Super,c),a&&b&&b.prototype.Dependencies){var f,g,h,i=b.prototype.Dependencies;for(f in i)if(i.hasOwnProperty(f)){if(g=i[f],h=e&&g===d?this._getValueForIdentifier(g,c,!0):this._getValueForIdentifier(g,c),null===h)throw new Error(g+" is required by "+a+" but was not mapped on the injector.");a[f]=h}}a._hasDependenciesInjected=!0,a.useDependencies&&a.useDependencies.call(a)}}})}();
//     Underscore.js 1.6.0
//     http://underscorejs.org
//     (c) 2009-2014 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
//     Underscore may be freely distributed under the MIT license.

(function() {

  // Baseline setup
  // --------------

  // Establish the root object, `window` in the browser, or `exports` on the server.
  var root = this;

  // Save the previous value of the `_` variable.
  var previousUnderscore = root._;

  // Establish the object that gets returned to break out of a loop iteration.
  var breaker = {};

  // Save bytes in the minified (but not gzipped) version:
  var ArrayProto = Array.prototype, ObjProto = Object.prototype, FuncProto = Function.prototype;

  // Create quick reference variables for speed access to core prototypes.
  var
    push             = ArrayProto.push,
    slice            = ArrayProto.slice,
    concat           = ArrayProto.concat,
    toString         = ObjProto.toString,
    hasOwnProperty   = ObjProto.hasOwnProperty;

  // All **ECMAScript 5** native function implementations that we hope to use
  // are declared here.
  var
    nativeForEach      = ArrayProto.forEach,
    nativeMap          = ArrayProto.map,
    nativeReduce       = ArrayProto.reduce,
    nativeReduceRight  = ArrayProto.reduceRight,
    nativeFilter       = ArrayProto.filter,
    nativeEvery        = ArrayProto.every,
    nativeSome         = ArrayProto.some,
    nativeIndexOf      = ArrayProto.indexOf,
    nativeLastIndexOf  = ArrayProto.lastIndexOf,
    nativeIsArray      = Array.isArray,
    nativeKeys         = Object.keys,
    nativeBind         = FuncProto.bind;

  // Create a safe reference to the Underscore object for use below.
  var _ = function(obj) {
    if (obj instanceof _) return obj;
    if (!(this instanceof _)) return new _(obj);
    this._wrapped = obj;
  };

  // Export the Underscore object for **Node.js**, with
  // backwards-compatibility for the old `require()` API. If we're in
  // the browser, add `_` as a global object via a string identifier,
  // for Closure Compiler "advanced" mode.
  if (typeof exports !== 'undefined') {
    if (typeof module !== 'undefined' && module.exports) {
      exports = module.exports = _;
    }
    exports._ = _;
  } else {
    root._ = _;
  }

  // Current version.
  _.VERSION = '1.6.0';

  // Collection Functions
  // --------------------

  // The cornerstone, an `each` implementation, aka `forEach`.
  // Handles objects with the built-in `forEach`, arrays, and raw objects.
  // Delegates to **ECMAScript 5**'s native `forEach` if available.
  var each = _.each = _.forEach = function(obj, iterator, context) {
    if (obj == null) return obj;
    if (nativeForEach && obj.forEach === nativeForEach) {
      obj.forEach(iterator, context);
    } else if (obj.length === +obj.length) {
      for (var i = 0, length = obj.length; i < length; i++) {
        if (iterator.call(context, obj[i], i, obj) === breaker) return;
      }
    } else {
      var keys = _.keys(obj);
      for (var i = 0, length = keys.length; i < length; i++) {
        if (iterator.call(context, obj[keys[i]], keys[i], obj) === breaker) return;
      }
    }
    return obj;
  };

  // Return the results of applying the iterator to each element.
  // Delegates to **ECMAScript 5**'s native `map` if available.
  _.map = _.collect = function(obj, iterator, context) {
    var results = [];
    if (obj == null) return results;
    if (nativeMap && obj.map === nativeMap) return obj.map(iterator, context);
    each(obj, function(value, index, list) {
      results.push(iterator.call(context, value, index, list));
    });
    return results;
  };

  var reduceError = 'Reduce of empty array with no initial value';

  // **Reduce** builds up a single result from a list of values, aka `inject`,
  // or `foldl`. Delegates to **ECMAScript 5**'s native `reduce` if available.
  _.reduce = _.foldl = _.inject = function(obj, iterator, memo, context) {
    var initial = arguments.length > 2;
    if (obj == null) obj = [];
    if (nativeReduce && obj.reduce === nativeReduce) {
      if (context) iterator = _.bind(iterator, context);
      return initial ? obj.reduce(iterator, memo) : obj.reduce(iterator);
    }
    each(obj, function(value, index, list) {
      if (!initial) {
        memo = value;
        initial = true;
      } else {
        memo = iterator.call(context, memo, value, index, list);
      }
    });
    if (!initial) throw new TypeError(reduceError);
    return memo;
  };

  // The right-associative version of reduce, also known as `foldr`.
  // Delegates to **ECMAScript 5**'s native `reduceRight` if available.
  _.reduceRight = _.foldr = function(obj, iterator, memo, context) {
    var initial = arguments.length > 2;
    if (obj == null) obj = [];
    if (nativeReduceRight && obj.reduceRight === nativeReduceRight) {
      if (context) iterator = _.bind(iterator, context);
      return initial ? obj.reduceRight(iterator, memo) : obj.reduceRight(iterator);
    }
    var length = obj.length;
    if (length !== +length) {
      var keys = _.keys(obj);
      length = keys.length;
    }
    each(obj, function(value, index, list) {
      index = keys ? keys[--length] : --length;
      if (!initial) {
        memo = obj[index];
        initial = true;
      } else {
        memo = iterator.call(context, memo, obj[index], index, list);
      }
    });
    if (!initial) throw new TypeError(reduceError);
    return memo;
  };

  // Return the first value which passes a truth test. Aliased as `detect`.
  _.find = _.detect = function(obj, predicate, context) {
    var result;
    any(obj, function(value, index, list) {
      if (predicate.call(context, value, index, list)) {
        result = value;
        return true;
      }
    });
    return result;
  };

  // Return all the elements that pass a truth test.
  // Delegates to **ECMAScript 5**'s native `filter` if available.
  // Aliased as `select`.
  _.filter = _.select = function(obj, predicate, context) {
    var results = [];
    if (obj == null) return results;
    if (nativeFilter && obj.filter === nativeFilter) return obj.filter(predicate, context);
    each(obj, function(value, index, list) {
      if (predicate.call(context, value, index, list)) results.push(value);
    });
    return results;
  };

  // Return all the elements for which a truth test fails.
  _.reject = function(obj, predicate, context) {
    return _.filter(obj, function(value, index, list) {
      return !predicate.call(context, value, index, list);
    }, context);
  };

  // Determine whether all of the elements match a truth test.
  // Delegates to **ECMAScript 5**'s native `every` if available.
  // Aliased as `all`.
  _.every = _.all = function(obj, predicate, context) {
    predicate || (predicate = _.identity);
    var result = true;
    if (obj == null) return result;
    if (nativeEvery && obj.every === nativeEvery) return obj.every(predicate, context);
    each(obj, function(value, index, list) {
      if (!(result = result && predicate.call(context, value, index, list))) return breaker;
    });
    return !!result;
  };

  // Determine if at least one element in the object matches a truth test.
  // Delegates to **ECMAScript 5**'s native `some` if available.
  // Aliased as `any`.
  var any = _.some = _.any = function(obj, predicate, context) {
    predicate || (predicate = _.identity);
    var result = false;
    if (obj == null) return result;
    if (nativeSome && obj.some === nativeSome) return obj.some(predicate, context);
    each(obj, function(value, index, list) {
      if (result || (result = predicate.call(context, value, index, list))) return breaker;
    });
    return !!result;
  };

  // Determine if the array or object contains a given value (using `===`).
  // Aliased as `include`.
  _.contains = _.include = function(obj, target) {
    if (obj == null) return false;
    if (nativeIndexOf && obj.indexOf === nativeIndexOf) return obj.indexOf(target) != -1;
    return any(obj, function(value) {
      return value === target;
    });
  };

  // Invoke a method (with arguments) on every item in a collection.
  _.invoke = function(obj, method) {
    var args = slice.call(arguments, 2);
    var isFunc = _.isFunction(method);
    return _.map(obj, function(value) {
      return (isFunc ? method : value[method]).apply(value, args);
    });
  };

  // Convenience version of a common use case of `map`: fetching a property.
  _.pluck = function(obj, key) {
    return _.map(obj, _.property(key));
  };

  // Convenience version of a common use case of `filter`: selecting only objects
  // containing specific `key:value` pairs.
  _.where = function(obj, attrs) {
    return _.filter(obj, _.matches(attrs));
  };

  // Convenience version of a common use case of `find`: getting the first object
  // containing specific `key:value` pairs.
  _.findWhere = function(obj, attrs) {
    return _.find(obj, _.matches(attrs));
  };

  // Return the maximum element or (element-based computation).
  // Can't optimize arrays of integers longer than 65,535 elements.
  // See [WebKit Bug 80797](https://bugs.webkit.org/show_bug.cgi?id=80797)
  _.max = function(obj, iterator, context) {
    if (!iterator && _.isArray(obj) && obj[0] === +obj[0] && obj.length < 65535) {
      return Math.max.apply(Math, obj);
    }
    var result = -Infinity, lastComputed = -Infinity;
    each(obj, function(value, index, list) {
      var computed = iterator ? iterator.call(context, value, index, list) : value;
      if (computed > lastComputed) {
        result = value;
        lastComputed = computed;
      }
    });
    return result;
  };

  // Return the minimum element (or element-based computation).
  _.min = function(obj, iterator, context) {
    if (!iterator && _.isArray(obj) && obj[0] === +obj[0] && obj.length < 65535) {
      return Math.min.apply(Math, obj);
    }
    var result = Infinity, lastComputed = Infinity;
    each(obj, function(value, index, list) {
      var computed = iterator ? iterator.call(context, value, index, list) : value;
      if (computed < lastComputed) {
        result = value;
        lastComputed = computed;
      }
    });
    return result;
  };

  // Shuffle an array, using the modern version of the
  // [Fisher-Yates shuffle](http://en.wikipedia.org/wiki/Fisherâ€“Yates_shuffle).
  _.shuffle = function(obj) {
    var rand;
    var index = 0;
    var shuffled = [];
    each(obj, function(value) {
      rand = _.random(index++);
      shuffled[index - 1] = shuffled[rand];
      shuffled[rand] = value;
    });
    return shuffled;
  };

  // Sample **n** random values from a collection.
  // If **n** is not specified, returns a single random element.
  // The internal `guard` argument allows it to work with `map`.
  _.sample = function(obj, n, guard) {
    if (n == null || guard) {
      if (obj.length !== +obj.length) obj = _.values(obj);
      return obj[_.random(obj.length - 1)];
    }
    return _.shuffle(obj).slice(0, Math.max(0, n));
  };

  // An internal function to generate lookup iterators.
  var lookupIterator = function(value) {
    if (value == null) return _.identity;
    if (_.isFunction(value)) return value;
    return _.property(value);
  };

  // Sort the object's values by a criterion produced by an iterator.
  _.sortBy = function(obj, iterator, context) {
    iterator = lookupIterator(iterator);
    return _.pluck(_.map(obj, function(value, index, list) {
      return {
        value: value,
        index: index,
        criteria: iterator.call(context, value, index, list)
      };
    }).sort(function(left, right) {
        var a = left.criteria;
        var b = right.criteria;
        if (a !== b) {
          if (a > b || a === void 0) return 1;
          if (a < b || b === void 0) return -1;
        }
        return left.index - right.index;
      }), 'value');
  };

  // An internal function used for aggregate "group by" operations.
  var group = function(behavior) {
    return function(obj, iterator, context) {
      var result = {};
      iterator = lookupIterator(iterator);
      each(obj, function(value, index) {
        var key = iterator.call(context, value, index, obj);
        behavior(result, key, value);
      });
      return result;
    };
  };

  // Groups the object's values by a criterion. Pass either a string attribute
  // to group by, or a function that returns the criterion.
  _.groupBy = group(function(result, key, value) {
    _.has(result, key) ? result[key].push(value) : result[key] = [value];
  });

  // Indexes the object's values by a criterion, similar to `groupBy`, but for
  // when you know that your index values will be unique.
  _.indexBy = group(function(result, key, value) {
    result[key] = value;
  });

  // Counts instances of an object that group by a certain criterion. Pass
  // either a string attribute to count by, or a function that returns the
  // criterion.
  _.countBy = group(function(result, key) {
    _.has(result, key) ? result[key]++ : result[key] = 1;
  });

  // Use a comparator function to figure out the smallest index at which
  // an object should be inserted so as to maintain order. Uses binary search.
  _.sortedIndex = function(array, obj, iterator, context) {
    iterator = lookupIterator(iterator);
    var value = iterator.call(context, obj);
    var low = 0, high = array.length;
    while (low < high) {
      var mid = (low + high) >>> 1;
      iterator.call(context, array[mid]) < value ? low = mid + 1 : high = mid;
    }
    return low;
  };

  // Safely create a real, live array from anything iterable.
  _.toArray = function(obj) {
    if (!obj) return [];
    if (_.isArray(obj)) return slice.call(obj);
    if (obj.length === +obj.length) return _.map(obj, _.identity);
    return _.values(obj);
  };

  // Return the number of elements in an object.
  _.size = function(obj) {
    if (obj == null) return 0;
    return (obj.length === +obj.length) ? obj.length : _.keys(obj).length;
  };

  // Array Functions
  // ---------------

  // Get the first element of an array. Passing **n** will return the first N
  // values in the array. Aliased as `head` and `take`. The **guard** check
  // allows it to work with `_.map`.
  _.first = _.head = _.take = function(array, n, guard) {
    if (array == null) return void 0;
    if ((n == null) || guard) return array[0];
    if (n < 0) return [];
    return slice.call(array, 0, n);
  };

  // Returns everything but the last entry of the array. Especially useful on
  // the arguments object. Passing **n** will return all the values in
  // the array, excluding the last N. The **guard** check allows it to work with
  // `_.map`.
  _.initial = function(array, n, guard) {
    return slice.call(array, 0, array.length - ((n == null) || guard ? 1 : n));
  };

  // Get the last element of an array. Passing **n** will return the last N
  // values in the array. The **guard** check allows it to work with `_.map`.
  _.last = function(array, n, guard) {
    if (array == null) return void 0;
    if ((n == null) || guard) return array[array.length - 1];
    return slice.call(array, Math.max(array.length - n, 0));
  };

  // Returns everything but the first entry of the array. Aliased as `tail` and `drop`.
  // Especially useful on the arguments object. Passing an **n** will return
  // the rest N values in the array. The **guard**
  // check allows it to work with `_.map`.
  _.rest = _.tail = _.drop = function(array, n, guard) {
    return slice.call(array, (n == null) || guard ? 1 : n);
  };

  // Trim out all falsy values from an array.
  _.compact = function(array) {
    return _.filter(array, _.identity);
  };

  // Internal implementation of a recursive `flatten` function.
  var flatten = function(input, shallow, output) {
    if (shallow && _.every(input, _.isArray)) {
      return concat.apply(output, input);
    }
    each(input, function(value) {
      if (_.isArray(value) || _.isArguments(value)) {
        shallow ? push.apply(output, value) : flatten(value, shallow, output);
      } else {
        output.push(value);
      }
    });
    return output;
  };

  // Flatten out an array, either recursively (by default), or just one level.
  _.flatten = function(array, shallow) {
    return flatten(array, shallow, []);
  };

  // Return a version of the array that does not contain the specified value(s).
  _.without = function(array) {
    return _.difference(array, slice.call(arguments, 1));
  };

  // Split an array into two arrays: one whose elements all satisfy the given
  // predicate, and one whose elements all do not satisfy the predicate.
  _.partition = function(array, predicate, context) {
    predicate = lookupIterator(predicate);
    var pass = [], fail = [];
    each(array, function(elem) {
      (predicate.call(context, elem) ? pass : fail).push(elem);
    });
    return [pass, fail];
  };

  // Produce a duplicate-free version of the array. If the array has already
  // been sorted, you have the option of using a faster algorithm.
  // Aliased as `unique`.
  _.uniq = _.unique = function(array, isSorted, iterator, context) {
    if (_.isFunction(isSorted)) {
      context = iterator;
      iterator = isSorted;
      isSorted = false;
    }
    var initial = iterator ? _.map(array, iterator, context) : array;
    var results = [];
    var seen = [];
    each(initial, function(value, index) {
      if (isSorted ? (!index || seen[seen.length - 1] !== value) : !_.contains(seen, value)) {
        seen.push(value);
        results.push(array[index]);
      }
    });
    return results;
  };

  // Produce an array that contains the union: each distinct element from all of
  // the passed-in arrays.
  _.union = function() {
    return _.uniq(_.flatten(arguments, true));
  };

  // Produce an array that contains every item shared between all the
  // passed-in arrays.
  _.intersection = function(array) {
    var rest = slice.call(arguments, 1);
    return _.filter(_.uniq(array), function(item) {
      return _.every(rest, function(other) {
        return _.contains(other, item);
      });
    });
  };

  // Take the difference between one array and a number of other arrays.
  // Only the elements present in just the first array will remain.
  _.difference = function(array) {
    var rest = concat.apply(ArrayProto, slice.call(arguments, 1));
    return _.filter(array, function(value){ return !_.contains(rest, value); });
  };

  // Zip together multiple lists into a single array -- elements that share
  // an index go together.
  _.zip = function() {
    var length = _.max(_.pluck(arguments, 'length').concat(0));
    var results = new Array(length);
    for (var i = 0; i < length; i++) {
      results[i] = _.pluck(arguments, '' + i);
    }
    return results;
  };

  // Converts lists into objects. Pass either a single array of `[key, value]`
  // pairs, or two parallel arrays of the same length -- one of keys, and one of
  // the corresponding values.
  _.object = function(list, values) {
    if (list == null) return {};
    var result = {};
    for (var i = 0, length = list.length; i < length; i++) {
      if (values) {
        result[list[i]] = values[i];
      } else {
        result[list[i][0]] = list[i][1];
      }
    }
    return result;
  };

  // If the browser doesn't supply us with indexOf (I'm looking at you, **MSIE**),
  // we need this function. Return the position of the first occurrence of an
  // item in an array, or -1 if the item is not included in the array.
  // Delegates to **ECMAScript 5**'s native `indexOf` if available.
  // If the array is large and already in sort order, pass `true`
  // for **isSorted** to use binary search.
  _.indexOf = function(array, item, isSorted) {
    if (array == null) return -1;
    var i = 0, length = array.length;
    if (isSorted) {
      if (typeof isSorted == 'number') {
        i = (isSorted < 0 ? Math.max(0, length + isSorted) : isSorted);
      } else {
        i = _.sortedIndex(array, item);
        return array[i] === item ? i : -1;
      }
    }
    if (nativeIndexOf && array.indexOf === nativeIndexOf) return array.indexOf(item, isSorted);
    for (; i < length; i++) if (array[i] === item) return i;
    return -1;
  };

  // Delegates to **ECMAScript 5**'s native `lastIndexOf` if available.
  _.lastIndexOf = function(array, item, from) {
    if (array == null) return -1;
    var hasIndex = from != null;
    if (nativeLastIndexOf && array.lastIndexOf === nativeLastIndexOf) {
      return hasIndex ? array.lastIndexOf(item, from) : array.lastIndexOf(item);
    }
    var i = (hasIndex ? from : array.length);
    while (i--) if (array[i] === item) return i;
    return -1;
  };

  // Generate an integer Array containing an arithmetic progression. A port of
  // the native Python `range()` function. See
  // [the Python documentation](http://docs.python.org/library/functions.html#range).
  _.range = function(start, stop, step) {
    if (arguments.length <= 1) {
      stop = start || 0;
      start = 0;
    }
    step = arguments[2] || 1;

    var length = Math.max(Math.ceil((stop - start) / step), 0);
    var idx = 0;
    var range = new Array(length);

    while(idx < length) {
      range[idx++] = start;
      start += step;
    }

    return range;
  };

  // Function (ahem) Functions
  // ------------------

  // Reusable constructor function for prototype setting.
  var ctor = function(){};

  // Create a function bound to a given object (assigning `this`, and arguments,
  // optionally). Delegates to **ECMAScript 5**'s native `Function.bind` if
  // available.
  _.bind = function(func, context) {
    var args, bound;
    if (nativeBind && func.bind === nativeBind) return nativeBind.apply(func, slice.call(arguments, 1));
    if (!_.isFunction(func)) throw new TypeError;
    args = slice.call(arguments, 2);
    return bound = function() {
      if (!(this instanceof bound)) return func.apply(context, args.concat(slice.call(arguments)));
      ctor.prototype = func.prototype;
      var self = new ctor;
      ctor.prototype = null;
      var result = func.apply(self, args.concat(slice.call(arguments)));
      if (Object(result) === result) return result;
      return self;
    };
  };

  // Partially apply a function by creating a version that has had some of its
  // arguments pre-filled, without changing its dynamic `this` context. _ acts
  // as a placeholder, allowing any combination of arguments to be pre-filled.
  _.partial = function(func) {
    var boundArgs = slice.call(arguments, 1);
    return function() {
      var position = 0;
      var args = boundArgs.slice();
      for (var i = 0, length = args.length; i < length; i++) {
        if (args[i] === _) args[i] = arguments[position++];
      }
      while (position < arguments.length) args.push(arguments[position++]);
      return func.apply(this, args);
    };
  };

  // Bind a number of an object's methods to that object. Remaining arguments
  // are the method names to be bound. Useful for ensuring that all callbacks
  // defined on an object belong to it.
  _.bindAll = function(obj) {
    var funcs = slice.call(arguments, 1);
    if (funcs.length === 0) throw new Error('bindAll must be passed function names');
    each(funcs, function(f) { obj[f] = _.bind(obj[f], obj); });
    return obj;
  };

  // Memoize an expensive function by storing its results.
  _.memoize = function(func, hasher) {
    var memo = {};
    hasher || (hasher = _.identity);
    return function() {
      var key = hasher.apply(this, arguments);
      return _.has(memo, key) ? memo[key] : (memo[key] = func.apply(this, arguments));
    };
  };

  // Delays a function for the given number of milliseconds, and then calls
  // it with the arguments supplied.
  _.delay = function(func, wait) {
    var args = slice.call(arguments, 2);
    return setTimeout(function(){ return func.apply(null, args); }, wait);
  };

  // Defers a function, scheduling it to run after the current call stack has
  // cleared.
  _.defer = function(func) {
    return _.delay.apply(_, [func, 1].concat(slice.call(arguments, 1)));
  };

  // Returns a function, that, when invoked, will only be triggered at most once
  // during a given window of time. Normally, the throttled function will run
  // as much as it can, without ever going more than once per `wait` duration;
  // but if you'd like to disable the execution on the leading edge, pass
  // `{leading: false}`. To disable execution on the trailing edge, ditto.
  _.throttle = function(func, wait, options) {
    var context, args, result;
    var timeout = null;
    var previous = 0;
    options || (options = {});
    var later = function() {
      previous = options.leading === false ? 0 : _.now();
      timeout = null;
      result = func.apply(context, args);
      context = args = null;
    };
    return function() {
      var now = _.now();
      if (!previous && options.leading === false) previous = now;
      var remaining = wait - (now - previous);
      context = this;
      args = arguments;
      if (remaining <= 0) {
        clearTimeout(timeout);
        timeout = null;
        previous = now;
        result = func.apply(context, args);
        context = args = null;
      } else if (!timeout && options.trailing !== false) {
        timeout = setTimeout(later, remaining);
      }
      return result;
    };
  };

  // Returns a function, that, as long as it continues to be invoked, will not
  // be triggered. The function will be called after it stops being called for
  // N milliseconds. If `immediate` is passed, trigger the function on the
  // leading edge, instead of the trailing.
  _.debounce = function(func, wait, immediate) {
    var timeout, args, context, timestamp, result;

    var later = function() {
      var last = _.now() - timestamp;
      if (last < wait) {
        timeout = setTimeout(later, wait - last);
      } else {
        timeout = null;
        if (!immediate) {
          result = func.apply(context, args);
          context = args = null;
        }
      }
    };

    return function() {
      context = this;
      args = arguments;
      timestamp = _.now();
      var callNow = immediate && !timeout;
      if (!timeout) {
        timeout = setTimeout(later, wait);
      }
      if (callNow) {
        result = func.apply(context, args);
        context = args = null;
      }

      return result;
    };
  };

  // Returns a function that will be executed at most one time, no matter how
  // often you call it. Useful for lazy initialization.
  _.once = function(func) {
    var ran = false, memo;
    return function() {
      if (ran) return memo;
      ran = true;
      memo = func.apply(this, arguments);
      func = null;
      return memo;
    };
  };

  // Returns the first function passed as an argument to the second,
  // allowing you to adjust arguments, run code before and after, and
  // conditionally execute the original function.
  _.wrap = function(func, wrapper) {
    return _.partial(wrapper, func);
  };

  // Returns a function that is the composition of a list of functions, each
  // consuming the return value of the function that follows.
  _.compose = function() {
    var funcs = arguments;
    return function() {
      var args = arguments;
      for (var i = funcs.length - 1; i >= 0; i--) {
        args = [funcs[i].apply(this, args)];
      }
      return args[0];
    };
  };

  // Returns a function that will only be executed after being called N times.
  _.after = function(times, func) {
    return function() {
      if (--times < 1) {
        return func.apply(this, arguments);
      }
    };
  };

  // Object Functions
  // ----------------

  // Retrieve the names of an object's properties.
  // Delegates to **ECMAScript 5**'s native `Object.keys`
  _.keys = function(obj) {
    if (!_.isObject(obj)) return [];
    if (nativeKeys) return nativeKeys(obj);
    var keys = [];
    for (var key in obj) if (_.has(obj, key)) keys.push(key);
    return keys;
  };

  // Retrieve the values of an object's properties.
  _.values = function(obj) {
    var keys = _.keys(obj);
    var length = keys.length;
    var values = new Array(length);
    for (var i = 0; i < length; i++) {
      values[i] = obj[keys[i]];
    }
    return values;
  };

  // Convert an object into a list of `[key, value]` pairs.
  _.pairs = function(obj) {
    var keys = _.keys(obj);
    var length = keys.length;
    var pairs = new Array(length);
    for (var i = 0; i < length; i++) {
      pairs[i] = [keys[i], obj[keys[i]]];
    }
    return pairs;
  };

  // Invert the keys and values of an object. The values must be serializable.
  _.invert = function(obj) {
    var result = {};
    var keys = _.keys(obj);
    for (var i = 0, length = keys.length; i < length; i++) {
      result[obj[keys[i]]] = keys[i];
    }
    return result;
  };

  // Return a sorted list of the function names available on the object.
  // Aliased as `methods`
  _.functions = _.methods = function(obj) {
    var names = [];
    for (var key in obj) {
      if (_.isFunction(obj[key])) names.push(key);
    }
    return names.sort();
  };

  // Extend a given object with all the properties in passed-in object(s).
  _.extend = function(obj) {
    each(slice.call(arguments, 1), function(source) {
      if (source) {
        for (var prop in source) {
          obj[prop] = source[prop];
        }
      }
    });
    return obj;
  };

  // Return a copy of the object only containing the whitelisted properties.
  _.pick = function(obj) {
    var copy = {};
    var keys = concat.apply(ArrayProto, slice.call(arguments, 1));
    each(keys, function(key) {
      if (key in obj) copy[key] = obj[key];
    });
    return copy;
  };

  // Return a copy of the object without the blacklisted properties.
  _.omit = function(obj) {
    var copy = {};
    var keys = concat.apply(ArrayProto, slice.call(arguments, 1));
    for (var key in obj) {
      if (!_.contains(keys, key)) copy[key] = obj[key];
    }
    return copy;
  };

  // Fill in a given object with default properties.
  _.defaults = function(obj) {
    each(slice.call(arguments, 1), function(source) {
      if (source) {
        for (var prop in source) {
          if (obj[prop] === void 0) obj[prop] = source[prop];
        }
      }
    });
    return obj;
  };

  // Create a (shallow-cloned) duplicate of an object.
  _.clone = function(obj) {
    if (!_.isObject(obj)) return obj;
    return _.isArray(obj) ? obj.slice() : _.extend({}, obj);
  };

  // Invokes interceptor with the obj, and then returns obj.
  // The primary purpose of this method is to "tap into" a method chain, in
  // order to perform operations on intermediate results within the chain.
  _.tap = function(obj, interceptor) {
    interceptor(obj);
    return obj;
  };

  // Internal recursive comparison function for `isEqual`.
  var eq = function(a, b, aStack, bStack) {
    // Identical objects are equal. `0 === -0`, but they aren't identical.
    // See the [Harmony `egal` proposal](http://wiki.ecmascript.org/doku.php?id=harmony:egal).
    if (a === b) return a !== 0 || 1 / a == 1 / b;
    // A strict comparison is necessary because `null == undefined`.
    if (a == null || b == null) return a === b;
    // Unwrap any wrapped objects.
    if (a instanceof _) a = a._wrapped;
    if (b instanceof _) b = b._wrapped;
    // Compare `[[Class]]` names.
    var className = toString.call(a);
    if (className != toString.call(b)) return false;
    switch (className) {
      // Strings, numbers, dates, and booleans are compared by value.
      case '[object String]':
        // Primitives and their corresponding object wrappers are equivalent; thus, `"5"` is
        // equivalent to `new String("5")`.
        return a == String(b);
      case '[object Number]':
        // `NaN`s are equivalent, but non-reflexive. An `egal` comparison is performed for
        // other numeric values.
        return a != +a ? b != +b : (a == 0 ? 1 / a == 1 / b : a == +b);
      case '[object Date]':
      case '[object Boolean]':
        // Coerce dates and booleans to numeric primitive values. Dates are compared by their
        // millisecond representations. Note that invalid dates with millisecond representations
        // of `NaN` are not equivalent.
        return +a == +b;
      // RegExps are compared by their source patterns and flags.
      case '[object RegExp]':
        return a.source == b.source &&
          a.global == b.global &&
          a.multiline == b.multiline &&
          a.ignoreCase == b.ignoreCase;
    }
    if (typeof a != 'object' || typeof b != 'object') return false;
    // Assume equality for cyclic structures. The algorithm for detecting cyclic
    // structures is adapted from ES 5.1 section 15.12.3, abstract operation `JO`.
    var length = aStack.length;
    while (length--) {
      // Linear search. Performance is inversely proportional to the number of
      // unique nested structures.
      if (aStack[length] == a) return bStack[length] == b;
    }
    // Objects with different constructors are not equivalent, but `Object`s
    // from different frames are.
    var aCtor = a.constructor, bCtor = b.constructor;
    if (aCtor !== bCtor && !(_.isFunction(aCtor) && (aCtor instanceof aCtor) &&
      _.isFunction(bCtor) && (bCtor instanceof bCtor))
      && ('constructor' in a && 'constructor' in b)) {
      return false;
    }
    // Add the first object to the stack of traversed objects.
    aStack.push(a);
    bStack.push(b);
    var size = 0, result = true;
    // Recursively compare objects and arrays.
    if (className == '[object Array]') {
      // Compare array lengths to determine if a deep comparison is necessary.
      size = a.length;
      result = size == b.length;
      if (result) {
        // Deep compare the contents, ignoring non-numeric properties.
        while (size--) {
          if (!(result = eq(a[size], b[size], aStack, bStack))) break;
        }
      }
    } else {
      // Deep compare objects.
      for (var key in a) {
        if (_.has(a, key)) {
          // Count the expected number of properties.
          size++;
          // Deep compare each member.
          if (!(result = _.has(b, key) && eq(a[key], b[key], aStack, bStack))) break;
        }
      }
      // Ensure that both objects contain the same number of properties.
      if (result) {
        for (key in b) {
          if (_.has(b, key) && !(size--)) break;
        }
        result = !size;
      }
    }
    // Remove the first object from the stack of traversed objects.
    aStack.pop();
    bStack.pop();
    return result;
  };

  // Perform a deep comparison to check if two objects are equal.
  _.isEqual = function(a, b) {
    return eq(a, b, [], []);
  };

  // Is a given array, string, or object empty?
  // An "empty" object has no enumerable own-properties.
  _.isEmpty = function(obj) {
    if (obj == null) return true;
    if (_.isArray(obj) || _.isString(obj)) return obj.length === 0;
    for (var key in obj) if (_.has(obj, key)) return false;
    return true;
  };

  // Is a given value a DOM element?
  _.isElement = function(obj) {
    return !!(obj && obj.nodeType === 1);
  };

  // Is a given value an array?
  // Delegates to ECMA5's native Array.isArray
  _.isArray = nativeIsArray || function(obj) {
    return toString.call(obj) == '[object Array]';
  };

  // Is a given variable an object?
  _.isObject = function(obj) {
    return obj === Object(obj);
  };

  // Add some isType methods: isArguments, isFunction, isString, isNumber, isDate, isRegExp.
  each(['Arguments', 'Function', 'String', 'Number', 'Date', 'RegExp'], function(name) {
    _['is' + name] = function(obj) {
      return toString.call(obj) == '[object ' + name + ']';
    };
  });

  // Define a fallback version of the method in browsers (ahem, IE), where
  // there isn't any inspectable "Arguments" type.
  if (!_.isArguments(arguments)) {
    _.isArguments = function(obj) {
      return !!(obj && _.has(obj, 'callee'));
    };
  }

  // Optimize `isFunction` if appropriate.
  if (typeof (/./) !== 'function') {
    _.isFunction = function(obj) {
      return typeof obj === 'function';
    };
  }

  // Is a given object a finite number?
  _.isFinite = function(obj) {
    return isFinite(obj) && !isNaN(parseFloat(obj));
  };

  // Is the given value `NaN`? (NaN is the only number which does not equal itself).
  _.isNaN = function(obj) {
    return _.isNumber(obj) && obj != +obj;
  };

  // Is a given value a boolean?
  _.isBoolean = function(obj) {
    return obj === true || obj === false || toString.call(obj) == '[object Boolean]';
  };

  // Is a given value equal to null?
  _.isNull = function(obj) {
    return obj === null;
  };

  // Is a given variable undefined?
  _.isUndefined = function(obj) {
    return obj === void 0;
  };

  // Shortcut function for checking if an object has a given property directly
  // on itself (in other words, not on a prototype).
  _.has = function(obj, key) {
    return hasOwnProperty.call(obj, key);
  };

  // Utility Functions
  // -----------------

  // Run Underscore.js in *noConflict* mode, returning the `_` variable to its
  // previous owner. Returns a reference to the Underscore object.
  _.noConflict = function() {
    root._ = previousUnderscore;
    return this;
  };

  // Keep the identity function around for default iterators.
  _.identity = function(value) {
    return value;
  };

  _.constant = function(value) {
    return function () {
      return value;
    };
  };

  _.property = function(key) {
    return function(obj) {
      return obj[key];
    };
  };

  // Returns a predicate for checking whether an object has a given set of `key:value` pairs.
  _.matches = function(attrs) {
    return function(obj) {
      if (obj === attrs) return true; //avoid comparing an object to itself.
      for (var key in attrs) {
        if (attrs[key] !== obj[key])
          return false;
      }
      return true;
    }
  };

  // Run a function **n** times.
  _.times = function(n, iterator, context) {
    var accum = Array(Math.max(0, n));
    for (var i = 0; i < n; i++) accum[i] = iterator.call(context, i);
    return accum;
  };

  // Return a random integer between min and max (inclusive).
  _.random = function(min, max) {
    if (max == null) {
      max = min;
      min = 0;
    }
    return min + Math.floor(Math.random() * (max - min + 1));
  };

  // A (possibly faster) way to get the current timestamp as an integer.
  _.now = Date.now || function() { return new Date().getTime(); };

  // List of HTML entities for escaping.
  var entityMap = {
    escape: {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#x27;'
    }
  };
  entityMap.unescape = _.invert(entityMap.escape);

  // Regexes containing the keys and values listed immediately above.
  var entityRegexes = {
    escape:   new RegExp('[' + _.keys(entityMap.escape).join('') + ']', 'g'),
    unescape: new RegExp('(' + _.keys(entityMap.unescape).join('|') + ')', 'g')
  };

  // Functions for escaping and unescaping strings to/from HTML interpolation.
  _.each(['escape', 'unescape'], function(method) {
    _[method] = function(string) {
      if (string == null) return '';
      return ('' + string).replace(entityRegexes[method], function(match) {
        return entityMap[method][match];
      });
    };
  });

  // If the value of the named `property` is a function then invoke it with the
  // `object` as context; otherwise, return it.
  _.result = function(object, property) {
    if (object == null) return void 0;
    var value = object[property];
    return _.isFunction(value) ? value.call(object) : value;
  };

  // Add your own custom functions to the Underscore object.
  _.mixin = function(obj) {
    each(_.functions(obj), function(name) {
      var func = _[name] = obj[name];
      _.prototype[name] = function() {
        var args = [this._wrapped];
        push.apply(args, arguments);
        return result.call(this, func.apply(_, args));
      };
    });
  };

  // Generate a unique integer id (unique within the entire client session).
  // Useful for temporary DOM ids.
  var idCounter = 0;
  _.uniqueId = function(prefix) {
    var id = ++idCounter + '';
    return prefix ? prefix + id : id;
  };

  // By default, Underscore uses ERB-style template delimiters, change the
  // following template settings to use alternative delimiters.
  _.templateSettings = {
    evaluate    : /<%([\s\S]+?)%>/g,
    interpolate : /<%=([\s\S]+?)%>/g,
    escape      : /<%-([\s\S]+?)%>/g
  };

  // When customizing `templateSettings`, if you don't want to define an
  // interpolation, evaluation or escaping regex, we need one that is
  // guaranteed not to match.
  var noMatch = /(.)^/;

  // Certain characters need to be escaped so that they can be put into a
  // string literal.
  var escapes = {
    "'":      "'",
    '\\':     '\\',
    '\r':     'r',
    '\n':     'n',
    '\t':     't',
    '\u2028': 'u2028',
    '\u2029': 'u2029'
  };

  var escaper = /\\|'|\r|\n|\t|\u2028|\u2029/g;

  // JavaScript micro-templating, similar to John Resig's implementation.
  // Underscore templating handles arbitrary delimiters, preserves whitespace,
  // and correctly escapes quotes within interpolated code.
  _.template = function(text, data, settings) {
    var render;
    settings = _.defaults({}, settings, _.templateSettings);

    // Combine delimiters into one regular expression via alternation.
    var matcher = new RegExp([
      (settings.escape || noMatch).source,
      (settings.interpolate || noMatch).source,
      (settings.evaluate || noMatch).source
    ].join('|') + '|$', 'g');

    // Compile the template source, escaping string literals appropriately.
    var index = 0;
    var source = "__p+='";
    text.replace(matcher, function(match, escape, interpolate, evaluate, offset) {
      source += text.slice(index, offset)
        .replace(escaper, function(match) { return '\\' + escapes[match]; });

      if (escape) {
        source += "'+\n((__t=(" + escape + "))==null?'':_.escape(__t))+\n'";
      }
      if (interpolate) {
        source += "'+\n((__t=(" + interpolate + "))==null?'':__t)+\n'";
      }
      if (evaluate) {
        source += "';\n" + evaluate + "\n__p+='";
      }
      index = offset + match.length;
      return match;
    });
    source += "';\n";

    // If a variable is not specified, place data values in local scope.
    if (!settings.variable) source = 'with(obj||{}){\n' + source + '}\n';

    source = "var __t,__p='',__j=Array.prototype.join," +
      "print=function(){__p+=__j.call(arguments,'');};\n" +
      source + "return __p;\n";

    try {
      render = new Function(settings.variable || 'obj', '_', source);
    } catch (e) {
      e.source = source;
      throw e;
    }

    if (data) return render(data, _);
    var template = function(data) {
      return render.call(this, data, _);
    };

    // Provide the compiled function source as a convenience for precompilation.
    template.source = 'function(' + (settings.variable || 'obj') + '){\n' + source + '}';

    return template;
  };

  // Add a "chain" function, which will delegate to the wrapper.
  _.chain = function(obj) {
    return _(obj).chain();
  };

  // OOP
  // ---------------
  // If Underscore is called as a function, it returns a wrapped object that
  // can be used OO-style. This wrapper holds altered versions of all the
  // underscore functions. Wrapped objects may be chained.

  // Helper function to continue chaining intermediate results.
  var result = function(obj) {
    return this._chain ? _(obj).chain() : obj;
  };

  // Add all of the Underscore functions to the wrapper object.
  _.mixin(_);

  // Add all mutator Array functions to the wrapper.
  each(['pop', 'push', 'reverse', 'shift', 'sort', 'splice', 'unshift'], function(name) {
    var method = ArrayProto[name];
    _.prototype[name] = function() {
      var obj = this._wrapped;
      method.apply(obj, arguments);
      if ((name == 'shift' || name == 'splice') && obj.length === 0) delete obj[0];
      return result.call(this, obj);
    };
  });

  // Add all accessor Array functions to the wrapper.
  each(['concat', 'join', 'slice'], function(name) {
    var method = ArrayProto[name];
    _.prototype[name] = function() {
      return result.call(this, method.apply(this._wrapped, arguments));
    };
  });

  _.extend(_.prototype, {

    // Start chaining a wrapped Underscore object.
    chain: function() {
      this._chain = true;
      return this;
    },

    // Extracts the result from a wrapped and chained object.
    value: function() {
      return this._wrapped;
    }

  });

  // AMD registration happens at the end for compatibility with AMD loaders
  // that may not enforce next-turn semantics on modules. Even though general
  // practice for AMD registration is to be anonymous, underscore registers
  // as a named module because, like jQuery, it is a base library that is
  // popular enough to be bundled in a third party lib, but not be part of
  // an AMD load request. Those cases could generate an error when an
  // anonymous define() is called outside of a loader request.
  if (typeof define === 'function' && define.amd) {
    define('underscore', [], function() {
      return _;
    });
  }
}).call(this);

Class('Fabric.IllustratorColorPicker', {

  Dependencies: {
    extendScript: 'Fabric.ExtendScriptApi',
    colorConverter: 'Fabric.ColorConverter'
  },

  pickColor: function(currentColor) {

    currentColor = this.colorConverter.convertHexStringToValue(currentColor);

    return this.extendScript.colorPicker(currentColor);

  }

});

Class('Fabric.PhotoshopActionManagerConstants', {

  Dependencies: {
    photoshop: 'Fabric.HostApplication'
  },

  useDependencies: function() {

    var app = this.photoshop;

    // ps class
    this.DOCUMENT = app.charIDToTypeID('Dcmn');
    this.TEXT_LAYER = app.charIDToTypeID('TxLr');
    this.PROPERTY = app.charIDToTypeID('Prpr');
    this.TEXT_LAYER = app.charIDToTypeID('TxLr');
    this.RGB_COLOR = app.charIDToTypeID('RGBC');

    // ps type
    this.ORDINAL = app.charIDToTypeID('Ordn');
    this.COLOR = app.charIDToTypeID('Clr ');
    this.TO = app.charIDToTypeID('T   ');

    // ps value
    this.TARGET = app.charIDToTypeID('Trgt');
    this.NULL = app.charIDToTypeID('null');

    // ps key
    this.LAYER = app.charIDToTypeID('Lyr ');
    this.LAYER_ID = app.charIDToTypeID('LyrI');
    this.TEXT_STYLE = app.charIDToTypeID('TxtS');
    this.RED = app.charIDToTypeID('Rd  ');
    this.GREEN = app.charIDToTypeID('Grn ');
    this.BLUE = app.charIDToTypeID('Bl  ');

    // ps action
    this.SET = app.charIDToTypeID('setd');
    this.SHOW = app.charIDToTypeID('Shw ');
    this.HIDE = app.charIDToTypeID('Hd  ');
    this.SELECT = app.charIDToTypeID("slct");
    this.MAKE_VISIBLE = app.charIDToTypeID( "MkVs" );

    // ps strings
    this.TARGET_LAYERS_STRING = app.stringIDToTypeID('targetLayers');
    this.LAYER_ID_STRING = app.stringIDToTypeID('layerID');
    this.LAYER_STRING = app.stringIDToTypeID('layer');
    this.CONTENT_LAYER = app.stringIDToTypeID('contentLayer');
    this.TEXT_OVERRIDE_FEATURE_NAME = app.stringIDToTypeID('textOverrideFeatureName');
    this.TEXT_STYLE_OPERATION_TYPE = app.stringIDToTypeID('typeStyleOperationType');
    this.SOLID_COLOR_LAYER = app.stringIDToTypeID('solidColorLayer');

    this.LAYER_SELECTION = app.stringIDToTypeID('layerSection');
    this.SELECTION_MODIFIER = app.stringIDToTypeID( "selectionModifier" );
    this.SELECTION_MODIFIER_TYPE = app.stringIDToTypeID( "selectionModifierType" );
    this.ADD_TO_SELECTION = app.stringIDToTypeID( "addToSelection" );

  }

});

Class('Fabric.PhotoshopColorPicker', {

  Dependencies: {
    colorConverter: 'Fabric.ColorConverter',
    photoshop: 'Fabric.HostApplication',
    SolidColor: 'Fabric.SolidColor'
  },

  pickColor: function(currentColor) {

    var color = null;

    // set photoshop foreground color to the color we want to display
    // when the color picker opens.
    if(currentColor) {

      var colorToShow = this.colorConverter.convertHexStringToRGB(currentColor),
          foregroundColor = new this.SolidColor();

      // set the photoshop foreground color to given color
      foregroundColor.rgb.red = colorToShow.red;
      foregroundColor.rgb.green = colorToShow.green;
      foregroundColor.rgb.blue = colorToShow.blue;

      this.photoshop.foregroundColor = foregroundColor;
    }

    var didPickColor = this.photoshop.showColorPicker(true);

    // if the user pressed "OK" he did pick otherwise he cancelled the dialog.
    if(didPickColor) {

      // the color picker sets the photoshop foreground color
      var pickedColor = this.photoshop.foregroundColor;

      color = this.colorConverter.convertRGBToHexValue(pickedColor.rgb);
    }

    return color;

  }

});

Class('Fabric.PhotoshopColorService', {

  Dependencies: {
    photoshop: 'Fabric.HostApplication',
    SolidColor: 'Fabric.SolidColor',
    colorConverter: 'Fabric.ColorConverter',
    ActionDescriptor: 'Fabric.PhotoshopActionDescriptor',
    constants: 'Fabric.PhotoshopActionManagerConstants'
  },

  getSolidColorForHexString: function(hexString) {

    var rgbColor = this.colorConverter.convertHexStringToRGB(hexString),
        solidColor = new this.ActionDescriptor();

    // define the color
    solidColor.putDouble(this.constants.RED, rgbColor.red);
    solidColor.putDouble(this.constants.GREEN, rgbColor.green);
    solidColor.putDouble(this.constants.BLUE, rgbColor.blue);

    return solidColor;
  }

});

Class('Fabric.PhotoshopDocumentService', {

  Dependencies: {
    photoshop: 'Fabric.HostApplication',
    colorConverter: 'Fabric.ColorConverter'
  },

  lastDocumentId: null,

  isActiveDocumentOpen: function() {
    return this.photoshop.documents.length > 0;
  },

  hasActiveDocumentChanged: function() {
    var activeDocumentId = null;
    if(this.isActiveDocumentOpen()) {
      activeDocumentId = this.photoshop.activeDocument.id;
    }
    var isDifferentDocument = this.lastDocumentId != activeDocumentId;
    this.lastDocumentId = activeDocumentId;
    return isDifferentDocument;
  },

  getActiveDocument: function() {
    if (this.isActiveDocumentOpen()) {
      return this.photoshop.activeDocument;
    }
    else {
      return null;
    }
  },

  getForegroundColor: function() {
    return this.colorConverter.convertRGBToHexValue(this.photoshop.foregroundColor.rgb);
  },

  setForegroundColor: function(hexColor) {
    var rgbColor = this.colorConverter.convertHexValueToRGB(hexColor);
    var fg = this.photoshop.foregroundColor.rgb;
    fg.red = rgbColor.red;
    fg.green = rgbColor.green;
    fg.blue = rgbColor.blue;
  }
});


Class('Fabric.PhotoshopLayerService', {

  Dependencies: {
    photoshop: 'Fabric.HostApplication',
    constants: 'Fabric.PhotoshopActionManagerConstants',
    hostColorService: 'Fabric.HostColorService',
    ActionReference: 'Fabric.PhotoshopActionReference',
    ActionDescriptor: 'Fabric.PhotoshopActionDescriptor',
    ActionList: 'Fabric.PhotoshopActionList',
    DialogModes: 'Fabric.PhotoshopDialogModes',
    documentService: 'Fabric.DocumentService',
    underscore: 'Fabric.Underscore'
  },

  lastSelectedLayerId: null,
  lastSelectedLayers: null,

  Constructor: function() {
    this.lastSelectedLayers = [];
  },

  hasDocumentBackgroundLayer: function (document) {
    try {
      document.backgroundLayer;
      return true;
    } catch (e) {
      return false;
    }
  },

  getSelectedItems: function (checkForRealLayers) {

    var selectedLayers = [];

    if (this.documentService.isActiveDocumentOpen()) {

      var getSelectedLayersAction = new this.ActionReference(),
        getSelectedLayersResult,
        activeDocument = this.documentService.getActiveDocument();

      getSelectedLayersAction.putEnumerated(this.constants.DOCUMENT, this.constants.ORDINAL, this.constants.TARGET);
      getSelectedLayersResult = this.photoshop.executeActionGet(getSelectedLayersAction);

      // check if there are multiple layers selected
      if (getSelectedLayersResult.hasKey(this.constants.TARGET_LAYERS_STRING)) {

        // get the layer list
        var layerList = getSelectedLayersResult.getList(this.constants.TARGET_LAYERS_STRING),
          backgroundLayerIndexOffset = this.hasDocumentBackgroundLayer(activeDocument) ? 0 : 1;

        for (var index = 0; index < layerList.count; index++) {

          var layerId = this.getLayerIdForIndex(layerList.getReference(index).getIndex() + backgroundLayerIndexOffset);

          selectedLayers.push(layerId);
        }
      }
      // only one active layer
      else {
        var activeLayerId = this.getActiveLayerId(checkForRealLayers);

        if (activeLayerId != null) {
          selectedLayers.push(activeLayerId);
        }
      }

    }

    return selectedLayers;
  },

  hasItemSelectionChanged: function (checkForRealLayers, singleLayerOnly) {

    var hasSelectionChanged = false;

    if(!this.documentService.isActiveDocumentOpen()) {

      if(this.lastSelectedLayerId != null || this.lastSelectedLayers.length > 0) {
        hasSelectionChanged = true;
      }

    }
    else {

      if(singleLayerOnly) {

        var selectedLayerId = this.getActiveLayerId(checkForRealLayers);

        if(this.lastSelectedLayerId != selectedLayerId) {

          this.lastSelectedLayerId = selectedLayerId;

          hasSelectionChanged = true;
        }

      } else {

        var selectedLayers = this.getSelectedItems(checkForRealLayers);

        if (!this.underscore.isEqual(selectedLayers, this.lastSelectedLayers)) {
          this.lastSelectedLayers = selectedLayers;
          hasSelectionChanged = true;
        }
      }

    }

    return hasSelectionChanged;

  },

  getActiveLayerId: function (checkForRealLayers) {

    var layerId = null;

    // return null if there is no active document
    if (this.documentService.isActiveDocumentOpen()) {

      if(!checkForRealLayers || (checkForRealLayers && this._isActiveLayerReal())) {

        var activeLayerDescriptor = this.getDescriptorOfActiveLayer();

        if (activeLayerDescriptor != null) {
          layerId = activeLayerDescriptor.getInteger(this.constants.LAYER_ID);
        }
      }
    }

    return layerId;

  },

  getDescriptorOfActiveLayer: function () {

    // return null if there is no active document
    if (!this.documentService.isActiveDocumentOpen()) {
      return null;
    }

    var reference = new this.ActionReference();

    reference.putEnumerated(this.constants.LAYER, this.constants.ORDINAL, this.constants.TARGET);

    return this.photoshop.executeActionGet(reference);
  },

  getLayerIdForIndex: function (index) {

    var getLayerAtIndexAction = new this.ActionReference();

    getLayerAtIndexAction.putIndex(this.constants.LAYER, index);

    return this.photoshop.executeActionGet(getLayerAtIndexAction).getInteger(this.constants.LAYER_ID_STRING);

  },

  updateColorOfLayer: function (layerId, color) {

    if (this.isTextLayer(layerId)) {

      this.setColorOfTextLayer(layerId, color);

    } else if (this.isShapeLayer(layerId)) {

      this.setColorOfShapeLayer(layerId, color);
    }

  },

  isTextLayer: function (layerId) {

    var getTextLayer = new this.ActionReference(),
      isAccessibleTextLayer = false;

    try {
      getTextLayer.putIdentifier(this.constants.TEXT_LAYER, layerId);
      this.photoshop.executeActionGet(getTextLayer);

      isAccessibleTextLayer = true;

    } catch (error) {
    }
    ;

    return isAccessibleTextLayer;

  },

  isShapeLayer: function (layerId) {

    var getShapeLayer = new this.ActionReference(),
      isAccessibleContentLayer = false;

    try {
      getShapeLayer.putIdentifier(this.constants.CONTENT_LAYER, layerId);
      this.photoshop.executeActionGet(getShapeLayer);

      isAccessibleContentLayer = true;

    } catch (error) {
    }
    ;

    return isAccessibleContentLayer;

  },

  isSupportedLayer: function(layerId) {
    return this.isTextLayer(layerId) || this.isShapeLayer(layerId);
  },

  setColorOfTextLayer: function (layerId, color) {

    var layerReference = new this.ActionReference(),
      setLayerColorDescriptor = new this.ActionDescriptor(),
      solidColor = this.hostColorService.getSolidColorForHexString(color),
      solidColorFill = new this.ActionDescriptor();

    // reference the text style property of given layer
    // the order is important here -> doesnt work if you put identifier first!
    layerReference.putProperty(this.constants.PROPERTY, this.constants.TEXT_STYLE);
    layerReference.putIdentifier(this.constants.TEXT_LAYER, layerId);

    // use the layer reference in the action
    setLayerColorDescriptor.putReference(this.constants.NULL, layerReference);

    // add the color description to the text color fill
    solidColorFill.putInteger(this.constants.TEXT_OVERRIDE_FEATURE_NAME, 808466226);
    solidColorFill.putInteger(this.constants.TEXT_STYLE_OPERATION_TYPE, 3);
    solidColorFill.putObject(this.constants.COLOR, this.constants.RGB_COLOR, solidColor);

    // add the fill to the action
    setLayerColorDescriptor.putObject(this.constants.TO, this.constants.TEXT_STYLE, solidColorFill);

    this.photoshop.executeAction(this.constants.SET, setLayerColorDescriptor, this.DialogModes.NO);

  },

  setColorOfShapeLayer: function (layerId, color) {

    var layerReference = new this.ActionReference(),
      setLayerColorAction = new this.ActionDescriptor(),
      solidColor = this.hostColorService.getSolidColorForHexString(color),
      solidColorFill = new this.ActionDescriptor();

    // set reference to layer with given id
    layerReference.putIdentifier(this.constants.CONTENT_LAYER, layerId);

    // use the layer reference in the action
    setLayerColorAction.putReference(this.constants.NULL, layerReference);

    // add the color description to the fill
    solidColorFill.putObject(this.constants.COLOR, this.constants.RGB_COLOR, solidColor);

    // add the fill to the action
    setLayerColorAction.putObject(this.constants.TO, this.constants.SOLID_COLOR_LAYER, solidColorFill);

    this.photoshop.executeAction(this.constants.SET, setLayerColorAction, this.DialogModes.NO);

  },

  _isActiveLayerReal: function () {

    var activeDocument = this.documentService.getActiveDocument(),
        activeLayer = activeDocument.activeLayer;

    // it is a real layer if it is not the first one in the layerset
    // this is because for ActionManager if no layer is selected
    // it still says the first one is selected.
    // the user however sees no layer selected … thanks Adobe!
    if(activeLayer != activeDocument.layers[0]) {
      return true;
    }

    var isRealActiveLayer = false,
        activeLayerIsVisible = activeLayer.visible;

    var action = new this.ActionDescriptor();
    var referenceList = new this.ActionList();
    var activeLayerReference = new this.ActionReference();

    activeLayerReference.putEnumerated(this.constants.LAYER, this.constants.ORDINAL, this.constants.TARGET);
    referenceList.putReference(activeLayerReference);
    action.putList(this.constants.NULL, referenceList);

    if(activeLayerIsVisible) {

      // the active layer is visible -> try to hide it with code
      this.photoshop.executeAction(this.constants.HIDE, action, this.DialogModes.NO);

      // if we could hide it with code its real
      if(activeLayer.visible == false) {

        isRealActiveLayer = true;

        // make it visible again
        this.photoshop.executeAction(this.constants.SHOW, action, this.DialogModes.NO);
      }
    }
    else {
      // the active layer is not visible -> try to make it visible via code
      this.photoshop.executeAction(this.constants.SHOW, action, this.DialogModes.NO);

      // if we could make it visible with code, its real
      if(activeLayer.visible == true) {

        isRealActiveLayer = true;

        // hide it again
        this.photoshop.executeAction(this.constants.HIDE, action, this.DialogModes.NO);
      }

    }

    return isRealActiveLayer;
  },

  selectLayers: function(layerIds) {

    var This = this,
        constants = this.constants;

    this.underscore.each(layerIds, function(layerId, index) {

      var layerReference = new This.ActionReference(),
          selectLayerAction = new This.ActionDescriptor();

      layerReference.putIdentifier(This.constants.LAYER, layerId);

      selectLayerAction.putReference(This.constants.NULL, layerReference);

      if(index > 0) {
        // add all elements to the select after the first was "just" selected
        selectLayerAction.putEnumerated(constants.SELECTION_MODIFIER, constants.SELECTION_MODIFIER_TYPE, constants.ADD_TO_SELECTION);
      }
      selectLayerAction.putBoolean( constants.MAKE_VISIBLE, false );

      This.photoshop.executeAction(This.constants.SELECT, selectLayerAction, This.DialogModes.NO);

    });

  }

});

Class('Fabric.PhotoshopSwatchService', {

  Dependencies: {
    photoshop: 'Fabric.HostApplication',
    metadataService: 'Fabric.MetadataService',
    itemsService: 'Fabric.ItemsService',
    underscore: 'Fabric.Underscore',
    documentService: 'Fabric.DocumentService',
    layerService: 'Fabric.ItemsService'
  },

  connectItemsWithSwatch: function(layerIds, swatchData) {

    var metadata = this._getMetadataForActiveDocument(),
        swatch = this._updateOrCreateSwatch(metadata, swatchData);

    if(!metadata.layers) {
      metadata.layers = {};
    }

    if(!swatch.connectedLayers) {
      swatch.connectedLayers = {};
    }

    for (var index = 0; index < layerIds.length; index++) {

      var layerId = layerIds[index];

      if(this.layerService.isSupportedLayer(layerId)) {

        // remove any previous connection to another swatch
        this._removeConnectionsOfLayer(metadata, layerId);

        swatch.connectedLayers[layerId] = layerId;

        metadata.layers[layerId] = { connectedSwatchId: swatch.id };

      }
    }

    this._saveMetadataForActiveDocument(metadata);

    this.updateConnectedItemsForSwatch(swatchData);

  },

  disconnectItemsFromSwatch: function(layerIds, swatch) {

    var metadata = this._getMetadataForActiveDocument(),
        connectedLayers = this._getConnectedLayersForSwatch(swatch.id),
        layersToDisconnect = this.underscore.intersection(layerIds, connectedLayers);

    for (var index = 0; index < layersToDisconnect.length; index++) {

      // remove connection to swatch
      this._removeConnectionsOfLayer(metadata, layersToDisconnect[index]);

    }

    this._saveMetadataForActiveDocument(metadata);

  },

  updateSwatchColor: function(swatchData) {

    var metadata = this._getMetadataForActiveDocument();

    this._updateOrCreateSwatch(metadata, swatchData);

    this._saveMetadataForActiveDocument(metadata);

    this.updateConnectedItemsForSwatch(swatchData);

  },

  updateConnectedItemsForSwatch: function(swatchData) {

    var connectedLayers = this._getConnectedLayersForSwatch(swatchData.id);

    var layerIds = this.underscore.map(connectedLayers, function(value, key) {
      return key;
    });

    this.setItemsColor(layerIds, swatchData.color);

  },

  setItemsColor: function(layerIds, color) {

    this.underscore.each(layerIds, function(layerId) {

      this.itemsService.updateColorOfLayer(layerId, color);

    }, this);

  },

  getAllSwatches: function() {
    return this._getMetadataForActiveDocument().swatches;
  },

  getConnectedSwatchIdsForLayers: function(layerIds) {

    var This = this,
        swatchIds = [];

    this.underscore.each(layerIds, function(layerId) {

      var swatchId = This._getConnectedSwatchIdForLayer(layerId);

      if(swatchId != null) {
        swatchIds.push(swatchId);
      }

    });

    return this.underscore.uniq(swatchIds);

  },

  getConnectedLayersOfSwatch: function(swatchId) {

    var connectedLayers = [],
        metadata = this._getMetadataForActiveDocument();

    if(metadata.swatches[swatchId] && metadata.swatches[swatchId].connectedLayers) {

      connectedLayers = this.underscore.map(metadata.swatches[swatchId].connectedLayers, function(layerId) {
        return layerId;
      });

    }

    return connectedLayers;

  },

  _updateOrCreateSwatch: function(metadata, swatchData) {

    if(metadata.swatches[swatchData.id]) {

      // the swatch already exists -> update the color!
      metadata.swatches[swatchData.id].color = swatchData.color;

    }
    else {

      // the swatch does not exist yet -> create it!
      metadata.swatches[swatchData.id] = {
        id: swatchData.id,
        color: swatchData.color
      };

    }

    return metadata.swatches[swatchData.id];
  },

  _getMetadataForActiveDocument: function() {

    var activeDocument = this.documentService.getActiveDocument(),
        metadata = this.metadataService.getMetadataForDocument(activeDocument);

    if(!metadata.swatches) {
      // Create an empty swatch collection if there is none yet
      metadata.swatches = {};
    }

    return metadata;

  },

  _saveMetadataForActiveDocument: function(data) {
    this.metadataService.setMetadataForDocument(this.photoshop.activeDocument, data);
  },

  _getConnectedLayersForSwatch: function(swatchId) {
    var metadata = this._getMetadataForActiveDocument();

    return metadata.swatches[swatchId].connectedLayers;
  },

  _getConnectedSwatchIdForLayer: function(layerId) {

    var metadata = this._getMetadataForActiveDocument();

    if(this._isLayerInMetadata(metadata, layerId)) {
      return metadata.layers[layerId].connectedSwatchId;
    }
    else {
      return null;
    }

  },

  _removeConnectionsOfLayer: function(metadata, layerId) {

    if(this._isLayerInMetadata(metadata, layerId)) {

      var connectedSwatchId = metadata.layers[layerId].connectedSwatchId;

      if(metadata.swatches[connectedSwatchId]) {

        delete metadata.swatches[connectedSwatchId].connectedLayers[layerId];

      }

      delete metadata.layers[layerId];
    }

  },

  _isLayerInMetadata: function(metadata, layerId) {

    if(metadata.layers && metadata.layers[layerId]) {
      return true;
    }
    else {
      return false;
    }

  }

});

Class('Fabric.MetadataService', {

  Dependencies: {
    XMP: 'Fabric.XMP',
    JSON: 'Fabric.JSON'
  },

  STATIC: {
    XMP_APP_METADATA: 'FabricMetadata'
  },

  appNamespaceURI: "http://ns.extensionfabric.com",
  appNamespacePrefix: 'fabric',

  setNamespace: function(namespaceURI, prefix) {

    this.appNamespaceURI = namespaceURI;
    this.appNamespacePrefix = prefix;

    XMPMeta.registerNamespace(namespaceURI, prefix);
  },

  getMetadataForDocument: function(document) {

    var xmpMetaDataObject = this._getDocumentXMPMetadataObject(document),
        appMetadata = xmpMetaDataObject.getProperty(this.appNamespaceURI, this.Class.XMP_APP_METADATA);

    if(appMetadata == null) {
      return {};
    }
    else {
      return this.JSON.parse(appMetadata);
    }

  },

  setMetadataForDocument: function(document, data) {

    var xmpMetaDataObject = this._getDocumentXMPMetadataObject(document);

    xmpMetaDataObject.setProperty(this.appNamespaceURI, this.Class.XMP_APP_METADATA, this.JSON.stringify(data));

    document.xmpMetadata.rawData = xmpMetaDataObject.serialize();
  },

  _getDocumentXMPMetadataObject: function(document) {
    return new XMPMeta(document.xmpMetadata.rawData);
  }

});

Class('Fabric.ColorConverter', {

  STATIC: {
    convertHexValueToString: function(hexValue) {
      var hexString = "000000" + hexValue.toString(16).toUpperCase();
      return '#' + hexString.substr(hexString.length - 6);
    },

    convertHexStringToValue: function(hexString) {
      return parseInt(hexString.substr(hexString.length - 6), 16);
    },

    convertHexValueToRGB: function (hexValue) {
      return {
        red: hexValue >> 16,
        green: hexValue >> 8 & 0xFF,
        blue: hexValue & 0xFF
      };
    },

    convertRGBToHexValue: function (rgb) {
      return Math.floor(rgb.red) << 16 | Math.floor(rgb.green) << 8 | Math.floor(rgb.blue);
    },

    convertHexStringToRGB: function(hexString) {
      var hexValue = Fabric.ColorConverter.convertHexStringToValue(hexString);
      return Fabric.ColorConverter.convertHexValueToRGB(hexValue);
    }
  }
});


function decodeHexEncodedString (encodedString) {
  var decoded = '';
  for (var i = 0; i < encodedString.length; i += 3) {
    decoded += String.fromCharCode('0x' + encodedString.substring(i, i + 3));
  }
  return decoded;
}

function executeFunctionWithEncodedParameter(hexEncodedParams) {
  var params = JSON.parse(decodeHexEncodedString(hexEncodedParams));
  var object = this[params.scriptName.split(".")[0]];
  var functionName = params.scriptName.split(".")[1];
  var script = object[functionName];
  return script.call(object, params.parameter);
}


Class('Fabric.ParameterEncoder', {


  STATIC: {

    encode: function (value) {

      var jsonString = JSON.stringify(value);
      var hexEncodedJsonString = '';
      var hex;
      var i = 0;

      while (i < jsonString.length) {
        hex = jsonString.charCodeAt(i++).toString(16);
        while (hex.length < 3) hex = '0' + hex;
        hexEncodedJsonString += hex;
      }

      return '<object><property id="json"><string>' + hexEncodedJsonString + '</string></property></object>';

    }
  }


});

Class('Prisma.Application', {

  Dependencies: {
    colorPicker: 'Fabric.ColorPicker',
    colorConverter: 'Fabric.ColorConverter',
    swatchService: 'Fabric.SwatchService',
    itemsService: 'Fabric.ItemsService',
    hostApplication: 'Fabric.HostApplication',
    metadataService: 'Fabric.MetadataService',
    underscore: 'Fabric.Underscore',
    documentService: 'Fabric.DocumentService',
    parameterEncoder: 'Fabric.ParameterEncoder'
  },

  useDependencies: function() {
    this.metadataService.setNamespace("http://prisma.codeadventure.com", "prisma");
  },

  showColorPickerDialog: function(parameter) {
    var pickedColor = this.colorPicker.pickColor(parameter.color);
    pickedColor = this.colorConverter.convertHexValueToString(pickedColor);
    return this.parameterEncoder.encode({ color: pickedColor });
  },

  connectSelectedItemsToSwatch: function (parameter) {
    // do nothing if there is no active document!
    if(this.documentService.isActiveDocumentOpen()) {
       var selectedItems = this.itemsService.getSelectedItems();
       this.swatchService.connectItemsWithSwatch(selectedItems, parameter.swatch);
    }
    return this.parameterEncoder.encode({ success: true });
  },

  disconnectSwatchFromSelectedItems: function (parameter) {
    // do nothing if there is no active document!
    if(this.documentService.isActiveDocumentOpen()) {
      var selectedItems = this.itemsService.getSelectedItems();
      this.swatchService.disconnectItemsFromSwatch(selectedItems, parameter.swatch);
    }
    return this.parameterEncoder.encode({ success: true });
  },

  updateSwatchColor: function(parameter) {
    // do nothing if there is no active document!
    if(this.documentService.isActiveDocumentOpen()) {
      this.swatchService.updateSwatchColor(parameter.swatch);
    }
    return this.parameterEncoder.encode({ success: true });
  },

  getSwatchesOfActiveDocument: function() {
    var result = {};
    // only search for swatches if there is an active document!
    if(this.documentService.isActiveDocumentOpen()) {
      var swatches = this.swatchService.getAllSwatches();
      for (var swatchId in swatches) {
        var swatch = swatches[swatchId];
        result[swatchId] = {
          id: swatch.id,
          color: swatch.color,
          layerCount: this.underscore.size(swatch.connectedLayers)
        };
      }
    }
    return this.parameterEncoder.encode(result);
  },

  getConnectedSwatchIdsForSelectedLayers: function() {
    var connectedSwatchIds = [];
    if(this.documentService.isActiveDocumentOpen()) {
      var selectedItems = this.itemsService.getSelectedItems(false);
      connectedSwatchIds = this.swatchService.getConnectedSwatchIdsForLayers(selectedItems);
    }
    return this.parameterEncoder.encode({
      swatchIds: connectedSwatchIds
    });
  },

  getSwatchIdOfSelectedLayer: function() {
    var connectedSwatchId = null;
    if(this.documentService.isActiveDocumentOpen()) {
      var selectedLayer = this.itemsService.getActiveLayerId(false);
      connectedSwatchIds = this.swatchService.getConnectedSwatchIdsForLayers([selectedLayer]);
      if(connectedSwatchIds.length) {
        connectedSwatchId = connectedSwatchIds[0];
      }
    }
    return this.parameterEncoder.encode({
      swatchIds: connectedSwatchId
    });
  },

  hasActiveDocumentChanged: function() {
    return this.parameterEncoder.encode({
      activeDocumentChanged: this.documentService.hasActiveDocumentChanged()
    });
  },

  hasItemSelectionChanged: function(parameter) {
    var checkRealLayers = parameter.checkForRealLayers,
        checkSingleLayerOnly = parameter.checkSingleLayerOnly;
    return this.parameterEncoder.encode({
      itemSelectionChanged: this.itemsService.hasItemSelectionChanged(checkRealLayers, checkSingleLayerOnly)
    });
  },

  selectConnectedLayersOfSwatch: function(parameter) {
    if(this.documentService.isActiveDocumentOpen()) {
      this.itemsService.selectLayers(this.swatchService.getConnectedLayersOfSwatch(parameter.swatchId));
    }
    return this.parameterEncoder.encode({ success: true });
  },

  getForegroundColor: function() {
    return this.parameterEncoder.encode({
      color: this.colorConverter.convertHexValueToString(
        this.documentService.getForegroundColor()
      )
    });
  },

  setForegroundColor: function(parameter) {
    hexColor = this.colorConverter.convertHexStringToValue(parameter.color);
    this.documentService.setForegroundColor(hexColor);
    return this.parameterEncoder.encode({ success: true });
  },

  selectFile: function(parameter) {
    var file = File.openDialog(parameter.prompt, parameter.filter);
    return this.parameterEncoder.encode({ path: file.fsName });
  }
});

﻿var injector = new Dependance.Injector();// =========== MAP VENDOR APIS =============injector.map('Fabric.JSON').toStaticValue(JSON);injector.map('Fabric.Underscore').toStaticValue(this._);injector.map('Fabric.XMP').toStaticValue(new ExternalObject('lib:AdobeXMPScript'));injector.map('Fabric.MetadataService').toSingleton(Fabric.MetadataService);// =========== MAP GLOBAL OBJECTS ==========injector.map('Fabric.ExtendScriptApi').toStaticValue($);injector.map('Fabric.HostApplication').toStaticValue(app);// =========== MAP UTILITIES ==========injector.map('Fabric.ColorConverter').toStaticValue(Fabric.ColorConverter);injector.map('Fabric.ParameterEncoder').toStaticValue(Fabric.ParameterEncoder);// =========== MAP HOST APPLICATION SPECIFIC CLASSES ==========if(app.name == "Adobe Photoshop") {  // SERVICES  injector.map('Fabric.ColorPicker').toSingleton(Fabric.PhotoshopColorPicker);  injector.map('Fabric.SwatchService').toSingleton(Fabric.PhotoshopSwatchService);  injector.map('Fabric.ItemsService').toSingleton(Fabric.PhotoshopLayerService);  injector.map('Fabric.HostColorService').toSingleton(Fabric.PhotoshopColorService);  injector.map('Fabric.DocumentService').toSingleton(Fabric.PhotoshopDocumentService);  // CONSTANTS  injector.map('Fabric.PhotoshopActionManagerConstants').toSingleton(Fabric.PhotoshopActionManagerConstants);  // PHOTOSHOP API  injector.map('Fabric.PhotoshopActionReference').toStaticValue(ActionReference);  injector.map('Fabric.PhotoshopActionDescriptor').toStaticValue(ActionDescriptor);  injector.map('Fabric.PhotoshopDialogModes').toStaticValue(DialogModes);  injector.map('Fabric.PhotoshopActionList').toStaticValue(ActionList);  injector.map('Fabric.SolidColor').toStaticValue(SolidColor);}if(app.name == "Adobe Illustrator") {  injector.map('Fabric.ColorPicker').toSingleton(Fabric.IllustratorColorPicker);}prisma = new Prisma.Application();injector.injectInto(prisma);